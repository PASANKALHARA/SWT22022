import React from 'react';

const Welcome = () => {
  return (
    <div style={{ textAlign: 'center', padding: '3rem' }}>
      <h1>Welcome to Foodie's Delight!</h1>
      <p>Your one-stop destination for delicious meals delivered to your doorstep.</p>
      <ul>
        <li>Browse a variety of cuisines</li>
        <li>Easy and secure food ordering</li>
        <li>Real-time order tracking</li>
      </ul>
    </div>
  );
};

export default Welcome;
