import React from 'react';
import './Form.css';

const FoodOrder = () => {
  return (
    <div className="container">
      <h2>Order Food</h2>
      <form>
        <select>
          <option value="">Select a food item</option>
          <option value="pizza">Pizza</option>
          <option value="burger">Burger</option>
          <option value="sushi">Sushi</option>
        </select>
        <input type="number" placeholder="Quantity" min="1" required />
        <button type="submit">Order</button>
      </form>
    </div>
  );
};

export default FoodOrder;
