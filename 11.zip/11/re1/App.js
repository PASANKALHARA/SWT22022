import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Welcome from './components/Welcome';
import Login from './components/Login';
import Register from './components/Register';
import FoodOrder from './components/FoodOrder';
import './App.css';

const App = () => {
  return (
    <Router>
      <header>
        <Link to="/">Home</Link>
        <Link to="/login">Login</Link>
        <Link to="/register">Register</Link>
        <Link to="/order-food">Order Food</Link>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/order-food" element={<FoodOrder />} />
        </Routes>
      </main>
    </Router>
  );
};

export default App;
