<?php
    require_once '../database/Expense.php';
    require_once '../database/Database.php';
    $database = new Database("localhost", "root", "", "expense_tracker");
    $db = $database->getConnection();
    $expense = new Expense($db);
    $expenses = $expense->getAllExpenses();
    $num = count($expenses);
    if ($num > 0) {
        $expenses_arr = array();
        $expenses_arr["records"] = $expenses;
        echo json_encode($expenses_arr);
    } else {
        echo json_encode(["records" => []]);
    }
?>