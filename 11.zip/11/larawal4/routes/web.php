<?php

use App\Http\Controllers\EmployeeController;

// Employee Management Routes
Route::get('employee', [EmployeeController::class, 'index']);
Route::get('employee/create', [EmployeeController::class, 'create']);
Route::post('employee/store', [EmployeeController::class, 'store']);
Route::get('employee/{id}/edit', [EmployeeController::class, 'edit']);
Route::post('employee/{id}/update', [EmployeeController::class, 'update']);
Route::delete('employee/{id}', [EmployeeController::class, 'delete']);
