<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreEmployeeRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'role' => 'required|string|max:255',
            'salary' => 'required|numeric|min:0',
            'age' => 'required|integer|min:18|max:65',
        ];
    }
}
