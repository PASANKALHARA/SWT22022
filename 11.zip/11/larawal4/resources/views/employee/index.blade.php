@extends('employee.layout')

@section('content')
<div class="mt-5 card">
    <h2 class="card-header">Employee Details</h2>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Salary</th>
                    <th>Age</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($employees as $employee)
                <tr>
                    <td>{{ $employee->name }}</td>
                    <td>{{ $employee->role }}</td>
                    <td>{{ $employee->salary }}</td>
                    <td>{{ $employee->age }}</td>
                    <td>
                        <a href="{{ url('employee/' . $employee->id . '/edit') }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ url('employee/' . $employee->id) }}" method="POST" style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5">There are no employees.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
