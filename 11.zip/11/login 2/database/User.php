<?php 
class User {
    public $id;
    public $username;
    public $email;
    public $password;
    public $age;
    public $address;

    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function setUserName($username) {
        $this->username = $username;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function setAge($age) {
        $this->age = $age;
    }

    public function setAddress($address) {
        $this->address = $address;
    }

    public function setPassword($password) {
        $this->password = $password;
    }

    public function register() {
        $hash_password = password_hash($this->password, PASSWORD_DEFAULT);
        $query = "INSERT INTO user (username, email, password, age, address) VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->conn, $query);

        if (!$stmt) {
            die("Statement preparation failed: " . mysqli_error($this->conn));
        }

        mysqli_stmt_bind_param($stmt, 'sssis', $this->username, $this->email, $hash_password, $this->age, $this->address);

        $result = mysqli_stmt_execute($stmt);
        if (!$result) {
            die("Execution failed: " . mysqli_error($this->conn));
        }

        mysqli_stmt_close($stmt);
        return $result;
    }

    public function login() {
        $query = "SELECT id, username, password FROM user WHERE username = ? LIMIT 1";
        $stmt = mysqli_prepare($this->conn, $query);

        if (!$stmt) {
            die("Statement preparation failed: " . mysqli_error($this->conn));
        }

        mysqli_stmt_bind_param($stmt, 's', $this->username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            if (password_verify($this->password, $row['password'])) {
                $this->id = $row['id'];
                $this->username = $row['username'];
                mysqli_stmt_close($stmt);
                return true;
            }
        }

        mysqli_stmt_close($stmt);
        return false;
    }
}
?>
