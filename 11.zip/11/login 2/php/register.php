<?php 
    session_start();
    require_once '../database/Db.php';
    require_once '../database/User.php';

    $db=new Db("localhost","root","","ex12");
    $db_connection=$db->getConnection();
    $user=new User($db_connection);

    $data=json_decode(file_get_contents("php://input"));
    $user->setUserName($data->username);
    $user->setPassword($data->password);
    $user->setEmail($data->email);
    $user->setAge($data->age);
    $user->setAddress($data->address);
    
    if ($user->register()) {
        echo json_encode(["message"=>"User was Registered."]);
    }else{
        echo json_encode(["message"=>"Unable to Registered the user."]);
    }
?>