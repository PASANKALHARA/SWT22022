<?php 
    session_start();
    require_once '../database/Db.php';
    require_once '../database/User.php';

    $db = new Db("localhost", "root", "", "ex12");
    $db_connection = $db->getConnection();
    $user = new User($db_connection);

    $data = json_decode(file_get_contents("php://input"));

    $user->setUserName($data->username);
    $user->setPassword($data->password);

    if ($user->login()) {
        $_SESSION['username'] = $user->username; 
        echo json_encode(["message" => "Login success"]);
    } else {
        echo json_encode(["message" => "Login failed. Invalid username or password."]);
    }
?>
