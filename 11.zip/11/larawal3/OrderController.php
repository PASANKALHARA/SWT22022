<?php

namespace App\Http\Controllers;

use App\Models\Food;
use App\Models\Dessert;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $foods = Food::where('user_id', auth()->id())->get();
        $desserts = Dessert::where('user_id', auth()->id())->get();
        return view('orders.index', compact('foods', 'desserts'));
    }

    public function storeFood(Request $request)
    {
        $request->validate([
            'food_name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'count' => 'required|integer|min:1',
            'veg_non_veg' => 'required|in:veg,non-veg',
            'additions' => 'nullable|string',
        ]);

        Food::create([
            'user_id' => auth()->id(),
            'food_name' => $request->food_name,
            'price' => $request->price,
            'count' => $request->count,
            'veg_non_veg' => $request->veg_non_veg,
            'additions' => $request->additions,
        ]);

        return redirect()->route('orders.index')->with('success', 'Food order placed successfully!');
    }

    public function storeDessert(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'count' => 'required|integer|min:1',
        ]);

        Dessert::create([
            'user_id' => auth()->id(),
            'name' => $request->name,
            'price' => $request->price,
            'count' => $request->count,
        ]);

        return redirect()->route('orders.index')->with('success', 'Dessert order placed successfully!');
    }
}