<?php

use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\OrderController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [RegisterController::class, 'register']);

Route::middleware(['auth'])->group(function () {
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::post('/orders/food', [OrderController::class, 'storeFood'])->name('orders.food.store');
    Route::post('/orders/dessert', [OrderController::class, 'storeDessert'])->name('orders.dessert.store');
});