@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Order Food</div>
                <div class="card-body">
                    <form method="POST" action="{{ route('orders.food.store') }}">
                        @csrf
                        <div class="form-group">
                            <label>Food Name</label>
                            <input type="text" name="food_name" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Price</label>
                            <input type="number" step="0.01" name="price" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Count</label>
                            <input type="number" name="count" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Type</label>
                            <select name="veg_non_veg" class="form-control" required>
                                <option value="veg">Vegetarian</option>
                                <option value="non-veg">Non-Vegetarian</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Additions</label>
                            <input type="text" name="additions" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-primary">Order Food</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Order Dessert</div>
                <div class="card-body">
                    <form method="POST" action="{{ route('orders.dessert.store') }}">
                        @csrf
                        <div class="form-group">
                            <label>Dessert Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Price</label>
                            <input type="number" step="0.01" name="price" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Count</label>
                            <input type="number" name="count" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Order Dessert</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection