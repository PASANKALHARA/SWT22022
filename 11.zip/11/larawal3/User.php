<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'phone_no',
    ];

    protected $hidden = [
        'password',
    ];

    public function foods()
    {
        return $this->hasMany(Food::class);
    }

    public function desserts()
    {
        return $this->hasMany(Dessert::class);
    }
}