<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Food extends Model
{
    protected $fillable = [
        'user_id',
        'food_name',
        'price',
        'count',
        'veg_non_veg',
        'additions',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}