@extends('layout')

@section('content')
<div class="mb-4 d-flex justify-content-between align-items-center">
    <h2>Students List</h2>
    <a href="{{ route('students.create') }}" class="btn btn-primary">Add New Student</a>
</div>

<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Age</th>
                <th>Faculty</th>
                <th>GPA</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($students as $student)
            <tr>
                <td>{{ $student->id }}</td>
                <td>{{ $student->First_Name }}</td>
                <td>{{ $student->Last_Name }}</td>
                <td>{{ $student->Age }}</td>
                <td>{{ $student->Faculty }}</td>
                <td>{{ $student->GPA }}</td>
                <td>{{ $student->Address }}</td>
                <td>
                    <div class="btn-group">
                        <a href="{{ route('students.edit', $student->id) }}" class="btn btn-sm btn-warning">Edit</a>
                        <form action="{{ route('students.destroy', $student->id) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="text-center">No students found.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
