@extends('layout')

@section('content')
<div class="mb-4 d-flex justify-content-between align-items-center">
    <h2>Teachers List</h2>
    <a href="{{ route('teachers.create') }}" class="btn btn-primary">Add New Teacher</a>
</div>

<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Age</th>
                <th>Faculty</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($teachers as $teacher)
            <tr>
                <td>{{ $teacher->id }}</td>
                <td>{{ $teacher->First_Name }}</td>
                <td>{{ $teacher->Last_Name }}</td>
                <td>{{ $teacher->Age }}</td>
                <td>{{ $teacher->Faculty }}</td>
                <td>{{ $teacher->Address }}</td>
                <td>
                    <div class="btn-group">
                        <a href="{{ route('teachers.edit', $teacher->id) }}" class="btn btn-sm btn-warning">Edit</a>
                        <form action="{{ route('teachers.destroy', $teacher->id) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7" class="text-center">No teachers found.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
