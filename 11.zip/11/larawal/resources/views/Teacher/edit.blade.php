@extends('layout')

@section('content')
<div class="card">
    <div class="card-header">
        <h3>Edit Teacher</h3>
    </div>
    <div class="card-body">
        <form action="{{ route('teachers.update', $teacher->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="mb-3">
                <label for="First_Name" class="form-label">First Name</label>
                <input type="text" class="form-control @error('First_Name') is-invalid @enderror" id="First_Name" name="First_Name" value="{{ old('First_Name', $teacher->First_Name) }}">
                @error('First_Name')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="mb-3">
                <label for="Last_Name" class="form-label">Last Name</label>
                <input type="text" class="form-control @error('Last_Name') is-invalid @enderror" id="Last_Name" name="Last_Name" value="{{ old('Last_Name', $teacher->Last_Name) }}">
                @error('Last_Name')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="mb-3">
                <label for="Age" class="form-label">Age</label>
                <input type="number" class="form-control @error('Age') is-invalid @enderror" id="Age" name="Age" value="{{ old('Age', $teacher->Age) }}">
                @error('Age')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="mb-3">
                <label for="Faculty" class="form-label">Faculty</label>
                <input type="text" class="form-control @error('Faculty') is-invalid @enderror" id="Faculty" name="Faculty" value="{{ old('Faculty', $teacher->Faculty) }}">
                @error('Faculty')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="mb-3">
                <label for="Address" class="form-label">Address</label>
                <input type="text" class="form-control @error('Address') is-invalid @enderror" id="Address" name="Address" value="{{ old('Address', $teacher->Address) }}">
                @error('Address')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Update Teacher</button>
                <a href="{{ route('teachers.index') }}" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
