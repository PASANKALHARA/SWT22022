<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TeacherRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // Changed from false to true
    }

    public function rules(): array
    {
        return [
            'First_Name' => 'required|string|max:255',
            'Last_Name' => 'required|string|max:255',
            'Age' => 'required|integer|min:21|max:80',
            'Faculty' => 'required|string|max:255',
            'Address' => 'required|string|max:255',
        ];
    }
}
