import { useContext } from 'react';
import { MyContext } from './ContextProvider';
const ComponentNew = () => {
    const { sharedData, setSharedData } = useContext(MyContext);
    return (
        <div>
            <p>{sharedData}</p>
            <button onClick={() => setSharedData("Updated Data")}>Update</button>
        </div>
    );
};
export default ComponentNew;