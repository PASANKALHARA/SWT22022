import { createContext, useState } from 'react';

export const MyContext = createContext();

const ContextProvider = ({ children }) => {
    const [sharedData, setSharedData] = useState("Initial Data");
    return (
        <MyContext.Provider value={{ sharedData, setSharedData }}>
            {children}
        </MyContext.Provider>
    );
};

export default ContextProvider;
