import { useEffect, useState } from 'react';
import axios from 'axios';
const DataFetchingAndPosting = () => {
    const [data, setData] = useState([]);
    const [newPost, setNewPost] = useState({
        title: '',
        body: '',
        userId: 1
    });
    // GET request to fetch data
    useEffect(() => {
        axios.get('https://jsonplaceholder.typicode.com/posts').then(response => setData(response.data)).catch(error => console.error(error));
    }, []);
    // POST request to add new data
    const handlePost = () => {
        axios.post('https://jsonplaceholder.typicode.com/posts',newPost).then(response => {
            console.log('New Post Added:', response.data);
            setData([...data, response.data]);
        }).catch(error => console.error(error));
    };
    return (
        <div>
            <h3>Data Fetching (GET Request)</h3>
            <ul>
                {data.map(post => <li key={post.id}>{post.title}</li>)}
            </ul>
            <h3>Add a New Post (POST Request)</h3>
            <input type="text" placeholder="Title" value={newPost.title} onChange={e => setNewPost({ ...newPost, title: e.target.value })}/>
            <input type="text" placeholder="Body" value={newPost.body} onChange={e => setNewPost({ ...newPost, body: e.target.value })}/>
            <button onClick={handlePost}>Add Post</button>
        </div>
    );
};
export default DataFetchingAndPosting;