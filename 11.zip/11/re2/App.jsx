
import DataFetchingAndPosting from './DataFetchingAndPosting';
function App() {
    return (
        <>
            <DataFetchingAndPosting />
        </>
    );
}
export default App;
